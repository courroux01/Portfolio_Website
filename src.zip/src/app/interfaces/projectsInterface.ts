export default interface projectInterface {
  id: string;
  title: string;
  subtitle: string;
  description: string[];
  image: string;
}
