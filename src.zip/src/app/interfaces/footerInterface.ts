export default interface footerInterface {
  mainText: string;
  listLabel: string;
  technologies: string[];
}
