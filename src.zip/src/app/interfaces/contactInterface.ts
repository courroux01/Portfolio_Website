export default interface contactInterface {
  mainText: string;
  links: { [key: string]: string };
  
}
