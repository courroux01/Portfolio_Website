export default interface headerInterface {
  name: string;
  role: string;
  motto: string;
}
