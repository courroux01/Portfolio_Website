export default interface aboutInterface {
  mainText: string;
  description: string[];
}
